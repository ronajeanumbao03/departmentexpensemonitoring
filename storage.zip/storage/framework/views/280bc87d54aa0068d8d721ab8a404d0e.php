<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800 dark:text-gray-100">Create New User</h1>
    </div>
    <?php if($errors->any()): ?>
        <div class="mb-4 text-red-500">
            <ul class="list-disc ml-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('users.store')); ?>" class="space-y-4 max-w-xl">
        <?php echo csrf_field(); ?>

        <div>
            <label class="block font-medium">First Name</label>
            <input name="first_name" value="<?php echo e(old('first_name')); ?>" required
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Middle Name</label>
            <input name="middle_name" value="<?php echo e(old('middle_name')); ?>"
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Last Name</label>
            <input name="last_name" value="<?php echo e(old('last_name')); ?>" required
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Username</label>
            <input name="username" value="<?php echo e(old('username')); ?>" required
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Email</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Address</label>
            <input name="address" value="<?php echo e(old('address')); ?>"
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Gender</label>
            <select name="gender" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
                <option value="">-- Select Gender --</option>
                <option value="male" <?php echo e(old('gender') === 'male' ? 'selected' : ''); ?>>Male</option>
                <option value="female" <?php echo e(old('gender') === 'female' ? 'selected' : ''); ?>>Female</option>
                <option value="other" <?php echo e(old('gender') === 'other' ? 'selected' : ''); ?>>Other</option>
            </select>
        </div>

        <div>
            <label class="block font-medium">Birthdate</label>
            <input type="date" name="birthdate" value="<?php echo e(old('birthdate')); ?>"
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Role</label>
            <select name="role" required class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
                <option value="admin" <?php echo e(old('role') === 'admin' ? 'selected' : ''); ?>>Admin</option>
                <option value="head" <?php echo e(old('role') === 'head' ? 'selected' : ''); ?>>Head</option>
                <option value="user" <?php echo e(old('role') === 'user' ? 'selected' : ''); ?>>User</option>
            </select>
        </div>

        <div>
            <label class="block font-medium">Status</label>
            <select name="status" required class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
                <option value="active" <?php echo e(old('status') === 'active' ? 'selected' : ''); ?>>Active</option>
                <option value="inactive" <?php echo e(old('status') === 'inactive' ? 'selected' : ''); ?>>Inactive</option>
            </select>
        </div>

        <div>
            <label class="block font-medium">Password</label>
            <input type="password" name="password" required
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Confirm Password</label>
            <input type="password" name="password_confirmation" required
                class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div class="pt-4">
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                Save User
            </button>
            <a href="<?php echo e(route('users.index')); ?>"
                class="ml-3 text-sm text-gray-600 dark:text-gray-300 hover:underline">Cancel</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/users/create.blade.php ENDPATH**/ ?>