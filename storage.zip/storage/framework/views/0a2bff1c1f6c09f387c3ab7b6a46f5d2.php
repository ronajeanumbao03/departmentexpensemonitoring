<!-- resources/views/events/create.blade.php -->

<?php $__env->startSection('content'); ?>
<h2>Add Event</h2>
<form action="<?php echo e(route('events.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3"><label>Name</label>
        <input type="text" name="event_name" class="form-control" required>
    </div>
    <div class="mb-3"><label>Description</label>
        <textarea name="event_description" class="form-control"></textarea>
    </div>
    <div class="mb-3"><label>Amount</label>
        <input type="number" name="amount" class="form-control"></input>
    </div>
    <div class="mb-3"><label>Section Applied To</label>
        <select name="applied_to" class="form-control">
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($section->section_id); ?>"><?php echo e($section->section_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button class="btn btn-success">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/events/create.blade.php ENDPATH**/ ?>