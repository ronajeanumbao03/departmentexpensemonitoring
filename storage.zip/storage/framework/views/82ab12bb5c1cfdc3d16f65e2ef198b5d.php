<?php $__env->startSection('content'); ?>
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-800 dark:text-gray-100">Create New Department</h1>
    </div>

    <form method="POST" action="<?php echo e(route('departments.store')); ?>" class="space-y-4 max-w-xl">
        <?php echo csrf_field(); ?>

        <div>
            <label class="block font-medium">Department Name</label>
            <input name="name" value="<?php echo e(old('name')); ?>" required
                   class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white">
        </div>

        <div>
            <label class="block font-medium">Description</label>
            <textarea name="description" class="w-full px-3 py-2 border rounded dark:bg-gray-700 dark:text-white"><?php echo e(old('description')); ?></textarea>
        </div>

        <div class="pt-4">
            <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Save Department</button>
            <a href="<?php echo e(route('departments.index')); ?>"
               class="ml-3 text-sm text-gray-600 dark:text-gray-300 hover:underline">Cancel</a>
        </div>
    </form>
    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        <?php if(session('success')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '<?php echo e(session('success')); ?>',
                confirmButtonColor: '#16a34a'
            });
        <?php endif; ?>

        <?php if(session('error')): ?>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: '<?php echo e(session('error')); ?>',
                confirmButtonColor: '#dc2626'
            });
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/departments/create.blade.php ENDPATH**/ ?>