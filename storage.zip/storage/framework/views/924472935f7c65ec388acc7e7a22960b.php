<?php $__env->startSection('content'); ?>
    <div class="max-w-4xl mx-auto">
        <h1 class="text-2xl font-bold text-gray-800 dark:text-white mb-6">My Notifications</h1>

        <?php if(session('success')): ?>
            <div class="mb-4 bg-green-100 text-green-800 px-4 py-2 rounded dark:bg-green-800 dark:text-green-100">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if($notifications->count() > 0): ?>
            <div class="bg-white dark:bg-gray-800 shadow rounded-lg divide-y divide-gray-200 dark:divide-gray-700">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="px-6 py-4 flex justify-between items-center">
                        <div class="flex-1">
                            <p class="text-sm text-gray-700 dark:text-gray-300">
                                <?php echo e($notification->message); ?>

                            </p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                                <?php echo e($notification->created_at->diffForHumans()); ?>

                            </p>
                        </div>

                        <?php if(!$notification->read): ?>
                            <form method="POST" action="<?php echo e(route('notifications.mark-read', $notification->id)); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="text-sm text-indigo-600 hover:underline dark:text-indigo-400">
                                    Mark as Read
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="mt-4">
                <?php echo e($notifications->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-gray-600 dark:text-gray-400 text-center py-12">
                You have no notifications.
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/notifications/index.blade.php ENDPATH**/ ?>