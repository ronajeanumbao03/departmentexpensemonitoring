<!-- resources/views/sections/create.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
     <div class="mt-6">
        <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-5">Add Section</h1>
     </div>
     <div class="mt-3">
        <!-- Success message-->
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session(('success'))); ?>

            </div>
        <?php endif; ?>

        <!-- Validation Errors-->
        <?php if($errors->any()): ?>
            <div class="alert alert-alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li> <?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e(session(('success'))); ?>

            </div>
        <?php endif; ?>
     </div>

     <div class="overflow-x-auto mt-3">
        <form action="<?php echo e(route('sections.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label class="form-label">Section Name: </label>
                <input type="text" name="section_name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Course and <br>Year Level (ex. BSIT-1):</label>
                <input type="text" name="year_level" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">No. of Students: </label>
                <input type="number" name="no_of_students" class="form-control" required>
            </div>
            <button class="btn btn-success bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700">Save</button>
            <button class="btn btn-danger bg-blue-red py-2 px-4 rounded-md hover:bg-indigo-700">
                <a href="<?php echo e(route('sections.index')); ?>" class="btn btn-danger" >Cancel</a>
            </button>

        </form>
     </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/sections/create.blade.php ENDPATH**/ ?>