<!-- resources/views/treasurers/index.blade.php -->

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between mb-3">
    <div class="mt-6">
        <h1 class="text-3xl font-semibold text-gray-800 dark:text-white mb-5">Treasurers Management</h1>
                <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700">
                    <a href="<?php echo e(route('treasurers.create')); ?>" class="btn btn-primary">Add Treasurer</a>
                </button>
    </div>

</div>
<div class="overflow-x-auto mt-3">
    <table class="min-w-full bg-white dark:bg-gray-800 rounded shadow">
        <thead class="table-dark">
            <tr class="bg-gray-100 dark:bg-gray-700 text-left">
                <th class="px-4 py-2">ID</th>
                <th class="px-4 py-2">Name</th>
                <th class="px-4 py-2">Section</th>
                <th class="px-4 py-2">Actions</th></tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $treasurers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treasurer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t border-gray-200 dark:border-gray-700">
                <td class="px-4 py-2"><?php echo e($treasurer->treasurer_id); ?></td>
                <td class="px-4 py-2"><?php echo e($treasurer->user->first_name.' '.$treasurer->user->last_name); ?></td>
                <td class="px-4 py-2"><?php echo e($treasurer->section->section_name); ?></td>
                <td class="px-4 py-2">
                    <a href="<?php echo e(route('treasurers.edit', $treasurer->treasurer_id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('treasurers.destroy', $treasurer->treasurer_id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-danger btn-sm">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/treasurers/index.blade.php ENDPATH**/ ?>