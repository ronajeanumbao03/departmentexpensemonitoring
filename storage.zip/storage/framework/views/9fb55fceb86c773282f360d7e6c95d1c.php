<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Edit Remittance</h2>
    <form action="<?php echo e(route('remittances.update', $remittance->remittance_id)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label>Treasurer</label>
            <input type="hidden" name="treasurer_id" value="<?php echo e(Auth::user()->id); ?>">
            
        </div>
        <div class="mb-3">
            <label>Amount</label>
            <input type="number" step="0.01" name="amount" value="<?php echo e($remittance->amount); ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Remittance Date</label>
            <input type="date" name="remittance_date" value="<?php echo e($remittance->remittance_date); ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Remarks</label>
            <input type="text" name="remarks" value="<?php echo e($remittance->remarks); ?>" class="form-control">
        </div>
        <button type="submit" class="btn btn-success">Update</button>
        <a href="<?php echo e(route('remittances.index')); ?>" class="btn btn-secondary">Cancel</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/remittances/edit.blade.php ENDPATH**/ ?>