<!-- resources/views/treasurers/create.blade.php -->

<?php $__env->startSection('content'); ?>
<h2>Add Treasurer</h2>
<form action="<?php echo e(route('treasurers.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-3"><label>Registered User</label>
        <select name="user_id" id="user_id" class="form-control">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($user->id); ?>"><?php echo e($user->first_name.' '.$user->last_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3"><label>Assign Section</label>
        <select name="section_assigned" class="form-control">
            <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($section->section_id); ?>"><?php echo e($section->section_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="mb-3"><label>Year Level</label>
       <select name="section_assigned" class="form-control">
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($section->section_id); ?>"><?php echo e(explode('-', $section->year_level)[1] ?? ''); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <button class="btn btn-success">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/treasurers/create.blade.php ENDPATH**/ ?>