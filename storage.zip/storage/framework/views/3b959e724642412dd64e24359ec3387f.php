<!-- resources/views/sections/index.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <!-- Heading -->
    <h2 class="text-3xl font-bold mb-4 text-gray-800">Sections Management</h2>
    <button type="submit" class="bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700">
            <a href="<?php echo e(route('sections.create')); ?>" class="btn btn-primary">Add Section</a>
    </button>

</div>

<table class="min-w-full bg-white dark:bg-gray-800 rounded shadow">
    <thead class="table-dark">
        <tr class="bg-gray-100 dark:bg-gray-700">
            <th  class="px-4 py-2">ID</th>
            <th  class="px-4 py-2">Section Name</th>
            <th class="px-4 py-2">Year Level</th>
            <th class="px-4 py-2"># of Students</th>
            <th class="px-4 py-2">Treasurers</th>
            <th class="px-4 py-2">Events</th>
            <th class="px-4 py-2">Actions</th>
        </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border-t border-gray-200 dark:border-gray-700">
            <td class="px-4 py-2"><?php echo e($section->section_id); ?></td>
            <td class="px-4 py-2"><?php echo e($section->section_name); ?></td>
            <td class="px-4 py-2"><?php echo e($section->year_level); ?></td>
            <td class="px-4 py-2"><?php echo e($section->no_of_students); ?></td>
            <td class="px-4 py-2">
                <?php $__currentLoopData = $section->treasurers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treasurer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge bg-info"><?php echo e($treasurer->user->first_name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td class="px-4 py-2">
                <?php $__currentLoopData = $section->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="badge bg-success"><?php echo e($event->event_name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td class="px-4 py-2">
                <a href="<?php echo e(route('sections.edit', $section->section_id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                <form action="<?php echo e(route('sections.destroy', $section->section_id)); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm"
                        onclick="return confirm('Are you sure?')">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dept-expenses-app\dept-expenses-app\resources\views/sections/index.blade.php ENDPATH**/ ?>